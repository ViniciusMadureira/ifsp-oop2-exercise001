# This Python file uses the following encoding: utf-8

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem
from controller.sqlite import SQLite
from controller.productdata import ProductData
from controller.categorydata import CategoryData
from model.product import Product
from model.category import Category
from view.productsform import Ui_Form
import os

class ProductsView(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
        self.__row = -1

    def init_ui(self):
        ui = Ui_Form()
        parent = ui.setupUi(self)
        self.__parent = parent
        table = self.__parent.tbl_products
        table.clicked.connect(self.table_onclicked)
        table.itemSelectionChanged.connect(self.table_changed)
        self.fill_combobox()
        self.fill_table()
        self.center()
        self.show()

    def center(self):
        # geometry of the main window
        qr = self.frameGeometry()
        # center point of screen
        cp = QtWidgets.QDesktopWidget().availableGeometry().center()
        # move rectangle's center point to screen's center point
        qr.moveCenter(cp)
        # top left of rectangle becomes top left of window centering it
        self.move(qr.topLeft())

    def table_changed(self):
        self.set_product_fields(-1)

    def table_onclicked(self):
        self.set_product_fields(-1)

    def set_product_fields(self, row):
        try:
            table = self.__parent.tbl_products
            if row == -1:
                index = table.selectionModel().currentIndex()
                row = index.row()
            product = Product()
            product.name = table.model().index(row, 2).data()
            product.description = table.model().index(row, 3).data()
            product.value = float(table.model().index(row, 4).data().replace(",", "."))
            category = Category()
            for c in CategoryData.categories:
                #print(int(c[0]), c[1], c[2], table.model().index(row, 1).data())
                if int(c[0]) == int(table.model().index(row, 1).data()):
                    category.id = int(c[0])
                    category.name = c[1]
                    category.description = c[2]
            product.category = category
            if product.is_valid():
                self.__parent.pte_product_name.setPlainText(product.name)
                self.__parent.pte_product_description.setPlainText(product.description)
                self.__parent.pte_product_value.setPlainText("R$" + str(product.value).replace(".", ","))
                self.set_product_category(product.category)
            #attrs = vars(product)
            #print(', '.join("%s: %s" % item for item in attrs.items()))
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))

    def set_product_category(self, category):
        combobox = self.__parent.cbx_product_categories
        for index in range(combobox.count()):
            if category.id == combobox.itemData(index).id:
                combobox.setCurrentIndex(index)

    def fill_table(self):
        rows = ProductData.load_products()
        table = self.__parent.tbl_products
        table.setRowCount(len(rows))
        table.setHorizontalHeaderLabels(["ID Produto", "ID Categoria", "Nome", 'Descrição', 'Valor', 'Categoria'])
        table.setColumnHidden(0, True);
        table.setColumnHidden(1, True);
        for i, row in enumerate(rows):
            for j, col in enumerate(row):
                item = QTableWidgetItem(str(col))
                table.setItem(i, j, item)
        table.setSizeAdjustPolicy(QtWidgets.QAbstractScrollArea.AdjustToContents)
        table.resizeColumnsToContents()

    def fill_combobox(self):
        rows = CategoryData.load_categories()
        combobox = self.__parent.cbx_product_categories
        combobox.clear()
        for row in rows:
            category = Category()
            category.id = row [0]
            category.name = row[1]
            category.description = row[2]
            if category.is_valid:
                combobox.addItem(row[1], category)

    def update_table():
        pass

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    pv = ProductsView()
    sys.exit(app.exec_())

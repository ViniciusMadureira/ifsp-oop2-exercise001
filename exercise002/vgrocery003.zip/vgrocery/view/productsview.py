# This Python file uses the following encoding: utf-8

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem, QPlainTextEdit, QFileDialog
from controller.sqlite import SQLite
from controller.productdata import ProductData
from controller.categorydata import CategoryData
from model.product import Product
from model.category import Category
from view.productsform import Ui_Form
import re
import os
from pathlib import Path
import sys
#import locale

#class ProductsView(QtWidgets.QWidget):
class ProductsView(Ui_Form):
    def __init__(self):
        super().__init__()
        self.init_ui()
        #self.__home_dir = str(Path.home()) # Transfer to MainFile if possible
        self.__home_dir = QtCore.QDir.homePath()
        self.__app_dir = self.__home_dir + "/vgrocery/"

    def init_ui(self):
        self.__form = QtWidgets.QWidget()
        self.setupUi(self.__form)

        table = self.tbl_products        
        table.clicked.connect(self.table_onclicked)
        table.itemSelectionChanged.connect(self.table_changed)

        pv = self.pte_product_value
        pv.focusOutEvent = self.pte_product_value_focusout
        pv.focusInEvent = self.pte_product_value_focusin
        #pv.mousePressEvent = self.pte_product_value_mousepressed
        #pv.keyPressEvent = self.pte_product_value_keypressed

        bp = self.btn_product_picture
        bp.clicked.connect(self.btn_product_picture_clicked)

        self.set_cbx_product_categories()
        self.fill_cbx_product_categories()
        self.set_tbl_products()
        self.fill_tbl_products()

        self.center()
        self.__form.show()
        self.pte_product_name.setFocus()

    def center(self):
        # geometry of the main window
        qr = self.__form.frameGeometry()
        # center point of screen
        cp = QtWidgets.QDesktopWidget().availableGeometry().center()
        # move rectangle's center point to screen's center point
        qr.moveCenter(cp)
        # top left of rectangle becomes top left of window centering it
        self.__form.move(qr.topLeft())

    def table_changed(self):
        self.set_product_fields(-1)

    def table_onclicked(self):
        self.set_product_fields(-1)

    def pte_product_value_focusout(self, event):
        try:
            text = self.pte_product_value.toPlainText()
            filtered = "".join([s for s in text if s.isdigit() or s in (".", ",")]).replace(",", ".")
            left_part = re.findall(r"^\d+", filtered)
            left_part = left_part[0] if len(left_part) > 0 else "0"
            right_part = re.findall(r"\..*", filtered)
            right_part = right_part[0].replace(".", "") if len(right_part) > 0 else "0"
            filtered = left_part + "." + right_part
            value = "R$" + QtCore.QLocale('pt_BR').toString(float(filtered), "f", 2)
            self.pte_product_value.setPlainText(value)
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        QPlainTextEdit.focusOutEvent(self.pte_product_value, QtGui.QFocusEvent(QtCore.QEvent.FocusOut))

    def pte_product_value_focusin(self, event):
        pte = self.pte_product_value
        try:
            pte.setPlainText(pte.toPlainText().replace("R$", ""))
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        self.setCursor(self.pte_product_value, 0)
        QPlainTextEdit.focusInEvent(pte, QtGui.QFocusEvent(QtCore.QEvent.FocusIn))

    def pte_product_value_mousepressed(self, event):
        pass
        #self.setCursor(self.pte_product_value, 0)

    def pte_product_value_keypressed(self, event):
        pte = self.pte_product_value
        print('key press:', (event.key(), event.text()))
        pte
        #QPlainTextEdit.keyPressedEvent(pte, QtGui.QKeyEvent(QtCore.QEvent.keyPressed))
        #pass

    def btn_product_picture_clicked(self):
        dlg = QFileDialog()
        dlg.setFileMode(QFileDialog.Directory|QFileDialog.ExistingFiles)
        dlg.setNameFilter("Imagens (*.jpg *.png *.gif)")
        dlg.setDirectory(self.__app_dir)
        if dlg.exec_():
            icon = QtGui.QIcon()
            try:
                image_path = dlg.selectedFiles()[0]
                if not os.path.exists(image_path):
                    image_path = ":/defaultimage_icon.png"
                icon.addPixmap(QtGui.QPixmap(image_path), QtGui.QIcon.Normal, QtGui.QIcon.Off)
                self.btn_product_picture.setIcon(icon)
            except:
                print("Unexpected error: {}".format(sys.exc_info()[0]))

    def setCursor(self, object, position):
        cursor = object.textCursor()
        cursor.setPosition(0)
        object.setTextCursor(cursor)

    def set_product_fields(self, row):
        try:
            table = self.tbl_products
            if row == -1:
                index = table.selectionModel().currentIndex()
                row = index.row()
            product = Product()
            product.name = table.model().index(row, 2).data()
            product.description = table.model().index(row, 3).data()
            product.value = float(table.model().index(row, 4).data().replace(",", "."))
            product.picture = table.model().index(row, 5).data()
            category = Category()
            for c in CategoryData.categories:
                #print(int(c[0]), c[1], c[2], table.model().index(row, 1).data())
                if int(c[0]) == int(table.model().index(row, 1).data()):
                    category.id = int(c[0])
                    category.name = c[1]
                    category.description = c[2]                    
            product.category = category
            if product.is_valid():
                self.pte_product_name.setPlainText(product.name)
                self.pte_product_description.setPlainText(product.description)
                self.pte_product_value.setPlainText("R${:.2f}".format(product.value).replace(".", ","))                
                icon = QtGui.QIcon()
                try:
                    image_path = self.__app_dir + product.picture
                    if not os.path.exists(image_path):
                        image_path = ":/defaultimage_icon.png"
                    icon.addPixmap(QtGui.QPixmap(image_path), QtGui.QIcon.Normal, QtGui.QIcon.Off)
                except:
                    print("Unexpected error: {}".format(sys.exc_info()[0]))
                self.btn_product_picture.setIcon(icon)
                self.set_selected_category(product.category)
            #attrs = vars(product)
            #print(', '.join("%s: %s" % item for item in attrs.items()))
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))

    def set_selected_category(self, category):
        combobox = self.cbx_product_categories
        for index in range(combobox.count()):
            if category.id == combobox.itemData(index).id:
                combobox.setCurrentIndex(index)

    def set_tbl_products(self):
        table = self.tbl_products
        table.setHorizontalHeaderLabels(["ID Produto", "ID Categoria", "Nome", 'Descrição', 'Valor (R$)', 'Imagem', 'Categoria'])
        table.setSizeAdjustPolicy(QtWidgets.QAbstractScrollArea.AdjustToContents)
        table.setColumnHidden(0, True)
        table.setColumnHidden(1, True)
        table.setColumnHidden(3, True)
        table.setColumnHidden(5, True)

    def fill_tbl_products(self):
        products = self.getAllProducts()
        table = self.tbl_products
        table.setRowCount(len(products))
        is_empty = len(products) < 1
        if not is_empty:
            self.lbl_tbl_products_empty.hide()
            for i, product in enumerate(products):
                fields = list(product.values())
                for j, col in enumerate(fields):
                    item = QTableWidgetItem(str(col))
                    if j == 4:
                        item.setTextAlignment(int(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter))
                    table.setItem(i, j, item)            
            table.resizeColumnsToContents()
            table.sortItems(2, QtCore.Qt.AscendingOrder)            
        else:
            self.lbl_tbl_products_empty.show()
        table.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff if is_empty else QtCore.Qt.ScrollBarAsNeeded)
        table.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff if is_empty else QtCore.Qt.ScrollBarAsNeeded)
        table.setColumnWidth(2, 440)

    def getAllProducts(self):
        tuples = ProductData.load_products()
        products = []
        for tuple in tuples:
            products.append({"id": tuple[0], "idCategory": tuple[1], "name": tuple[2], "description": tuple[3], "value": tuple[4], "picture": tuple[5], "nameCategory": tuple[6]})
        return products

    def set_cbx_product_categories(self):
        combobox = self.cbx_product_categories
        lne = QtWidgets.QLineEdit()
        lne.setReadOnly(True)
        lne.selectionChanged.connect(lambda: lne.setSelection(0, 0))
        lne.setPlaceholderText("Selecione uma categoria");
        combobox.setLineEdit(lne)

    def fill_cbx_product_categories(self):
        combobox = self.cbx_product_categories
        combobox.clear()        
        categories = self.getAllCategories()
        if len(categories) > 0:
            combobox.setEditable(False)
            for categ in categories:
                category = Category()
                category.id = categ["id"]
                category.name = categ["name"]
                category.description = categ["description"]
                if category.is_valid:
                    combobox.addItem(categ["name"], category)
        else:
            combobox.setEditable(True)
            combobox.setCurrentText("Nenhuma categoria encontrada")

    def getAllCategories(self):
        tuples = CategoryData.load_categories()
        categories = []
        for tuple in tuples:
            categories.append({"id": tuple[0], "name": tuple[1], "description": tuple[2]})
        return categories

    def update_table():
        pass

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    pv = ProductsView()
    sys.exit(app.exec_())

# This Python file uses the following encoding: utf-8

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem, QPlainTextEdit, QFileDialog
from controller.sqlite import SQLite
from controller.productdata import ProductData
from controller.categorydata import CategoryData
from model.product import Product
from model.category import Category
from view.productsform import Ui_frmProducts
import re
import os
from pathlib import Path
import sys
#import locale

#class ProductsView(QtWidgets.QWidget):
class ProductsView(Ui_frmProducts):
    def __init__(self):
        super().__init__()
        self.initUi()
        self.homeDir = QtCore.QDir.homePath()
        self.appDir = self.homeDir + "/vgrocery/"

    def initUi(self):
        self.form = QtWidgets.QWidget()
        self.setupUi(self.form)

        self.tblProducts.clicked.connect(self.tblProductsClicked)
        self.tblProducts.itemSelectionChanged.connect(self.tblProductsChanged)

        self.pteProductsSearch.textChanged.connect(self.pteProductsSearchTextChanged)
        self.pteProductName.focusOutEvent = self.pteProductNameFocusout
        self.pteProductName.focusInEvent = self.pteProductNameFocusin
        self.pteProductName.textChanged.connect(self.pteProductNameTextChanged)
        self.pteProductDescription.focusOutEvent = self.pteProductDescriptionFocusout
        self.pteProductDescription.focusInEvent = self.pteProductDescriptionFocusin
        self.pteProductDescription.textChanged.connect(self.pteProductDescriptionTextChanged)
        self.pteProductValue.focusOutEvent = self.pteProductValueFocusout
        self.pteProductValue.focusInEvent = self.pteProductValueFocusin
        self.pteProductValue.textChanged.connect(self.pteProductValueTextChanged)
        self.pteProductAmount.focusOutEvent = self.pteProductAmountFocusout
        self.pteProductAmount.focusInEvent = self.pteProductAmountFocusin
        self.pteProductAmount.textChanged.connect(self.pteProductAmountTextChanged)

        self.btnProductsSearchClear.clicked.connect(self.btnProductsSearchClearClicked)
        self.btnProductPicture.clicked.connect(self.btnProductPictureClicked)
        self.btnProductPictureDelete.clicked.connect(self.btnProductPictureDeleteClicked)
        self.btnProductsNew.clicked.connect(self.btnProductsNewClicked)
        self.btnProductsBack.clicked.connect(self.btnProductsBackClicked)

        self.setCbxProductCategories()
        self.fillCbxProductCategories()
        self.setTblProducts()
        self.fillTblProducts()

        self.lblProductNameValidation.hide()
        self.lblProductDescriptionValidation.hide()
        self.lblProductValueValidation.hide()        
        self.lblProductAmountValidation.hide()
        self.center()
        self.form.show()
        self.pteProductName.setFocus()

    def center(self):        
        qr = self.form.frameGeometry()        
        cp = QtWidgets.QDesktopWidget().availableGeometry().center()        
        qr.moveCenter(cp)        
        self.form.move(qr.topLeft())

    def pteProductsSearchTextChanged(self):
        rows = self.tblProducts.model().rowCount()
        cols = [2, 4, 6, 7]
        regex = "(?ui).*" + self.pteProductsSearch.toPlainText() + ".*"
        for row in range(rows):
            isHidden = True
            for col in cols:
                data = self.tblProducts.model().index(row, col).data()
                if re.match(regex, data):
                    isHidden = False
                    break
            self.tblProducts.setRowHidden(row, isHidden)

    def tblProductsChanged(self):
        self.setProductFields(-1)
        #self.pteProductNameFocusin(None)

    def tblProductsClicked(self):
        self.setProductFields(-1)
        #self.pteProductNameFocusin(None)

    def pteProductNameFocusout(self, event):
        isValid = False
        try:
            text = self.pteProductName.toPlainText().strip()
            self.pteProductName.setPlainText(text)
            isValid = 2 <= len(text) <= 100
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        self.validateObject(self.pteProductName, self.lblProductNameValidation, isValid)
        QPlainTextEdit.focusOutEvent(self.pteProductName, QtGui.QFocusEvent(QtCore.QEvent.FocusOut))

    def pteProductNameFocusin(self, event):
        try:
            self.setCursor(self.pteProductName, len(self.pteProductName.toPlainText()))
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        QPlainTextEdit.focusInEvent(self.pteProductName, QtGui.QFocusEvent(QtCore.QEvent.FocusIn))

    def pteProductNameTextChanged(self):
        isValid = 2 <= len(self.pteProductName.toPlainText()) <= 100
        self.validateObject(self.pteProductName, self.lblProductNameValidation, isValid)

    def pteProductDescriptionFocusout(self, event):
        isVaid = False
        try:
            text = self.pteProductDescription.toPlainText().strip()
            self.pteProductDescription.setPlainText(text)
            isValid = 2 <= len(text) <= 400 or len(text) == 0
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        self.validateObject(self.pteProductDescription, self.lblProductDescriptionValidation, isValid)
        QPlainTextEdit.focusOutEvent(self.pteProductDescription, QtGui.QFocusEvent(QtCore.QEvent.FocusOut))

    def pteProductDescriptionFocusin(self, event):
        try:            
            self.setCursor(self.pteProductDescription, len(self.pteProductDescription.toPlainText()))
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        QPlainTextEdit.focusInEvent(self.pteProductDescription, QtGui.QFocusEvent(QtCore.QEvent.FocusIn))

    def pteProductDescriptionTextChanged(self):
        textSize = len(self.pteProductDescription.toPlainText())
        isValid = 2 <= textSize <= 400 or textSize == 0
        self.validateObject(self.pteProductDescription, self.lblProductDescriptionValidation, isValid)

    def pteProductValueFocusout(self, event):
        isValid = False
        try:
            text = self.pteProductValue.toPlainText()
            filtered = "".join([s for s in text if s.isdigit() or s in (".", ",")]).replace(",", ".")
            leftPart = re.search(r"^((\d+\.)+|\d+)", filtered)            
            leftPart = leftPart.group(0).replace(".", "") if leftPart != None else "0"
            rightPart = re.search(r"(?<=\.)\d+$", filtered)            
            rightPart = rightPart.group(0).replace(".", "") if rightPart != None else "0"
            filtered = float(leftPart + "." + rightPart)
            value = "R$" + QtCore.QLocale('pt_BR').toString(filtered, "f", 2)
            self.pteProductValue.setPlainText(value)
            isValid = 0.0 <= filtered <= 100000.00
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        self.validateObject(self.pteProductValue, self.lblProductValueValidation, isValid)
        QPlainTextEdit.focusOutEvent(self.pteProductValue, QtGui.QFocusEvent(QtCore.QEvent.FocusOut))

    def pteProductValueFocusin(self, event):
        try:
            self.pteProductValue.setPlainText(pte.toPlainText().replace("R$", ""))        
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        self.setCursor(self.pteProductValue, 2)
        QPlainTextEdit.focusInEvent(self.pteProductValue, QtGui.QFocusEvent(QtCore.QEvent.FocusIn))

    def pteProductValueTextChanged(self):
        isValid = False
        try:
            text = self.pteProductValue.toPlainText().replace("R$", "").replace(".", "").replace(",", ".")
            filtered = float(text)
            isValid = 0.0 <= filtered <= 100000.00
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        self.validateObject(self.pteProductValue, self.lblProductValueValidation, isValid)

    def pteProductAmountFocusout(self, event):
        isValid = False
        try:
            text = self.pteProductAmount.toPlainText()
            filtered = "".join([s for s in text if s.isdigit()])
            filtered = int(filtered)
            value = str(filtered)
            self.pteProductAmount.setPlainText(value)
            isValid = 0 <= filtered <= 1000
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        self.validateObject(self.pteProductAmount, self.lblProductAmountValidation, isValid)
        QPlainTextEdit.focusOutEvent(self.pteProductAmount, QtGui.QFocusEvent(QtCore.QEvent.FocusOut))

    def pteProductAmountFocusin(self, event):
        self.setCursor(self.pteProductAmount, len(self.pteProductAmount.toPlainText()))
        QPlainTextEdit.focusInEvent(self.pteProductAmount, QtGui.QFocusEvent(QtCore.QEvent.FocusIn))

    def pteProductAmountTextChanged(self):
        isValid = False
        try:
            text = self.pteProductAmount.toPlainText()
            filtered = int(text)
            isValid = 0 <= filtered <= 1000
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        self.validateObject(self.pteProductAmount, self.lblProductAmountValidation, isValid)

    def btnProductsSearchClearClicked(self):
        self.pteProductsSearch.setPlainText("")
        self.pteProductsSearch.setFocus()
        rows = self.tblProducts.model().rowCount()
        for row in range(rows):
            self.tblProducts.setRowHidden(row, False)

    def btnProductPictureClicked(self):
        fileDialog = QFileDialog()
        fileDialog.setFileMode(QFileDialog.Directory|QFileDialog.ExistingFiles)
        fileDialog.setNameFilter("Imagens (*.jpg *.png *.gif)")
        fileDialog.setDirectory(self.appDir)
        if fileDialog.exec_():
            icon = QtGui.QIcon()
            try:
                imagePath = fileDialog.selectedFiles()[0]
                if not os.path.exists(imagePath):
                    imagePath = ":/defaultimage_icon.png"
                icon.addPixmap(QtGui.QPixmap(imagePath), QtGui.QIcon.Normal, QtGui.QIcon.Off)
                self.btnProductPicture.setIcon(icon)
            except:
                print("Unexpected error: {}".format(sys.exc_info()[0]))

    def btnProductPictureDeleteClicked(self):
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/defaultimage_icon.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnProductPicture.setIcon(icon)

    def btnProductsNewClicked(self):
        self.tblProducts.selectionModel().clearSelection()

        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/defaultimage_icon.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnProductPicture.setIcon(icon)

        self.pteProductName.setPlainText("")
        self.validateObject(self.pteProductName, self.lblProductNameValidation, True)
        self.pteProductDescription.setPlainText("")
        self.validateObject(self.pteProductDescription, self.lblProductDescriptionValidation, True)
        self.pteProductValue.setPlainText("R$0,00")
        self.validateObject(self.pteProductValue, self.lblProductValueValidation, True)

        self.cbxProductCategories.setCurrentIndex(0)

        self.pteProductName.setFocus()

    def btnProductsBackClicked(self):
        self.form.close()

    def validateObject(self, object, objectTextValidation, isValid):
        if isValid:
            objectTextValidation.hide()
            #color = "darkgreen"
            styleSheet = ""
        else:
            objectTextValidation.show()
            color = "darkred"
            styleSheet = "{} {{border-style: solid; border-width: 2px; border-color: {};}}".format(object.metaObject().className(), color)
        object.setStyleSheet(styleSheet)

    def setCursor(self, object, position):
        cursor = object.textCursor()
        cursor.setPosition(position)
        object.setTextCursor(cursor)

    def setProductFields(self, row):
        try:            
            if row == -1:
                index = self.tblProducts.selectionModel().currentIndex()
                row = index.row()
            product = Product()
            product.name = self.tblProducts.model().index(row, 2).data()
            product.description = self.tblProducts.model().index(row, 3).data()
            product.value = float(self.tblProducts.model().index(row, 4).data().replace(",", "."))            
            product.picture = self.tblProducts.model().index(row, 5).data()
            product.amount = int(self.tblProducts.model().index(row, 7).data())
            category = Category()
            for c in CategoryData.categories:                                                
                if int(c[0]) == int(self.tblProducts.model().index(row, 1).data()):
                    category.id = int(c[0])                    
                    category.name = c[1]                    
                    category.description = c[2]            
                    break
            if category.isValid():
                product.category = category
                if product.isValid():
                    self.pteProductName.setPlainText(product.name)
                    self.pteProductDescription.setPlainText(product.description)
                    self.pteProductValue.setPlainText("R${:.2f}".format(product.value).replace(".", ","))
                    self.pteProductAmount.setPlainText(str(product.amount))
                    icon = QtGui.QIcon()
                    try:
                        imagePath = self.appDir + product.picture
                        if not os.path.exists(imagePath):
                            imagePath = ":/defaultimage_icon.png"
                        icon.addPixmap(QtGui.QPixmap(imagePath), QtGui.QIcon.Normal, QtGui.QIcon.Off)
                    except:
                        print("Unexpected error: {}".format(sys.exc_info()[0]))
                    self.btnProductPicture.setIcon(icon)
                    self.setSelectedCategory(product.category)
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))

    def setSelectedCategory(self, category):
        for index in range(self.cbxProductCategories.count()):
            if category.id == self.cbxProductCategories.itemData(index).id:
                self.cbxProductCategories.setCurrentIndex(index)

    def setTblProducts(self):
        self.tblProducts.setHorizontalHeaderLabels(["ID Produto", "ID Categoria", "Nome", "Descrição", "Valor (R$)", "Imagem", "Categoria", "Quantidade"])
        self.tblProducts.setSizeAdjustPolicy(QtWidgets.QAbstractScrollArea.AdjustToContents)
        self.tblProducts.setColumnHidden(0, True)
        self.tblProducts.setColumnHidden(1, True)
        self.tblProducts.setColumnHidden(3, True)
        self.tblProducts.setColumnHidden(5, True)

    def fillTblProducts(self):
        products = self.getAllProducts()
        self.tblProducts.setRowCount(len(products))        
        is_empty = len(products) < 1
        if not is_empty:            
            self.lblTblProductsEmpty.hide()
            for i, product in enumerate(products):
                dict = {
                    "id": product.id,
                    "idCategory": product.category.id,
                    "name": product.name,
                    "description": product.description,
                    "value": str(product.value).replace(".", ","),
                    "picture": product.picture,
                    "nameCategory": product.category.name,
                    "amount": product.amount
                }
                fields = list(dict.values())
                for j, col in enumerate(fields):
                    item = QTableWidgetItem(str(col))
                    if j == 4 or j == 7:
                        item.setTextAlignment(int(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter))
                    self.tblProducts.setItem(i, j, item)
            self.tblProducts.resizeColumnsToContents()
            self.tblProducts.sortItems(2, QtCore.Qt.AscendingOrder)
        else:
            self.lblTblProductsEmpty.show()
        self.tblProducts.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff if is_empty else QtCore.Qt.ScrollBarAsNeeded)
        self.tblProducts.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff if is_empty else QtCore.Qt.ScrollBarAsNeeded)
        self.tblProducts.setColumnWidth(2, 440)

    def getAllProducts(self):
        tuples = ProductData.loadProducts()
        products = []
        for tuple in tuples:            
            product = Product()
            product.id = tuple[0]
            product.name = tuple[2]
            product.description = tuple[3]
            product.value = tuple[4]
            product.picture = tuple[5]
            product.amount = tuple[7]
            category = Category()
            category.id = tuple[1]
            category.name = tuple[6]
            if category.isValid():
                product.category = category
                if product.isValid():
                    products.append(product)
        return products

    def setCbxProductCategories(self):
        lne = QtWidgets.QLineEdit()
        lne.setReadOnly(True)
        lne.selectionChanged.connect(lambda: lne.setSelection(0, 0))
        lne.setPlaceholderText("Selecione uma categoria");
        self.cbxProductCategories.setLineEdit(lne)

    def fillCbxProductCategories(self):
        self.cbxProductCategories.clear()
        categories = self.getAllCategories()
        if len(categories) > 0:
            self.cbxProductCategories.setEditable(False)
            for category in categories:
                self.cbxProductCategories.addItem(category.name, category)
        else:
            self.cbxProductCategories.setEditable(True)
            self.cbxProductCategories.setCurrentText("Nenhuma categoria encontrada")

    def getAllCategories(self):
        tuples = CategoryData.loadCategories()
        categories = []
        for tuple in tuples:            
            category = Category()
            category.id = tuple[0]
            category.name = tuple[1]
            category.description = tuple[2]
            if category.isValid():
                categories.append(category)
        return categories

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    pv = ProductsView()
    sys.exit(app.exec_())

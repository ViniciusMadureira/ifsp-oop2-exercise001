# This Python file uses the following encoding: utf-8

from PyQt5 import QtCore, QtGui, QtWidgets

class StatusDialog(Ui_dlgStatus):
    def __init__(self):
        super().__init__()
        self.initUi()

    def initUi():
        self.form = QtWidgets.QWidget()
        self.setupUi(self.form)

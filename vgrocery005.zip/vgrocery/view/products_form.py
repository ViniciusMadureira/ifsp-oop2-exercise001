# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'products_form.ui'
#
# Created by: PyQt5 UI code generator 5.13.2
#
# WARNING! All changes made in this file will be lost!



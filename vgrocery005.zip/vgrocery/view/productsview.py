# This Python file uses the following encoding: utf-8

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem, QPlainTextEdit, QFileDialog
from controller.sqlite import SQLite
from controller.productdata import ProductData
from controller.categorydata import CategoryData
from model.product import Product
from model.category import Category
from view.productsform import Ui_frmProducts
import re
import os
from pathlib import Path
import sys
#import locale

#class ProductsView(QtWidgets.QWidget):
class ProductsView(Ui_frmProducts):
    def __init__(self):
        super().__init__()
        self.initUi()
        self.homeDir = QtCore.QDir.homePath()
        self.appDir = self.homeDir + "/vgrocery/"

    def initUi(self):
        self.form = QtWidgets.QWidget()
        self.setupUi(self.form)

        self.tblProducts.clicked.connect(self.tblProductsClicked)
        self.tblProducts.itemSelectionChanged.connect(self.tblProductsChanged)

        self.pteProductName.focusOutEvent = self.pteProductNameFocusout
        self.pteProductName.focusInEvent = self.pteProductNameFocusin
        self.pteProductDescription.focusOutEvent = self.pteProductDescriptionFocusout
        self.pteProductDescription.focusInEvent = self.pteProductDescriptionFocusin
        self.pteProductValue.focusOutEvent = self.pteProductValueFocusout
        self.pteProductValue.focusInEvent = self.pteProductValueFocusin

        self.btnProductPicture.clicked.connect(self.btnProductPictureClicked)
        self.btnProductPictureDelete.clicked.connect(self.btnProductPictureDeleteClicked)

        self.setCbxProductCategories()
        self.fillCbxProductCategories()
        self.setTblProducts()
        self.fillTblProducts()

        self.center()
        self.form.show()
        self.pteProductName.setFocus()

    def center(self):        
        qr = self.form.frameGeometry()        
        cp = QtWidgets.QDesktopWidget().availableGeometry().center()        
        qr.moveCenter(cp)        
        self.form.move(qr.topLeft())

    def tblProductsChanged(self):
        self.setProductFields(-1)

    def tblProductsClicked(self):
        self.setProductFields(-1)

    def pteProductNameFocusout(self, event):
        try:
            pass
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        QPlainTextEdit.focusOutEvent(self.pteProductName, QtGui.QFocusEvent(QtCore.QEvent.FocusOut))

    def pteProductNameFocusin(self, event):
        try:
            pass
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        QPlainTextEdit.focusInEvent(self.pteProductName, QtGui.QFocusEvent(QtCore.QEvent.FocusIn))

    def pteProductDescriptionFocusout(self, event):
        try:
            pass
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        QPlainTextEdit.focusOutEvent(self.pteProductDescription, QtGui.QFocusEvent(QtCore.QEvent.FocusOut))

    def pteProductDescriptionFocusin(self, event):
        try:
            pass
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        QPlainTextEdit.focusInEvent(self.pteProductDescription, QtGui.QFocusEvent(QtCore.QEvent.FocusIn))

    def pteProductValueFocusout(self, event):
        try:
            text = self.pteProductValue.toPlainText()
            filtered = "".join([s for s in text if s.isdigit() or s in (".", ",")]).replace(",", ".")
            left_part = re.findall(r"^\d+", filtered)
            left_part = left_part[0] if len(left_part) > 0 else "0"
            right_part = re.findall(r"\..*", filtered)
            right_part = right_part[0].replace(".", "") if len(right_part) > 0 else "0"
            filtered = left_part + "." + right_part
            value = "R$" + QtCore.QLocale('pt_BR').toString(float(filtered), "f", 2)
            self.pteProductValue.setPlainText(value)
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        QPlainTextEdit.focusOutEvent(self.pteProductValue, QtGui.QFocusEvent(QtCore.QEvent.FocusOut))

    def pteProductValueFocusin(self, event):
        try:
            self.pteProductValue.setPlainText(pte.toPlainText().replace("R$", ""))
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))
        self.setCursor(self.pteProductValue, 0)
        QPlainTextEdit.focusInEvent(self.pteProductValue, QtGui.QFocusEvent(QtCore.QEvent.FocusIn))

    def btnProductPictureClicked(self):
        fileDialog = QFileDialog()
        fileDialog.setFileMode(QFileDialog.Directory|QFileDialog.ExistingFiles)
        fileDialog.setNameFilter("Imagens (*.jpg *.png *.gif)")
        fileDialog.setDirectory(self.appDir)
        if fileDialog.exec_():
            icon = QtGui.QIcon()
            try:
                imagePath = fileDialog.selectedFiles()[0]
                if not os.path.exists(image_path):
                    imagePath = ":/defaultimage_icon.png"
                icon.addPixmap(QtGui.QPixmap(imagePath), QtGui.QIcon.Normal, QtGui.QIcon.Off)
                self.btnProductPicture.setIcon(icon)
            except:
                print("Unexpected error: {}".format(sys.exc_info()[0]))

    def btnProductPictureDeleteClicked(self):
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/defaultimage_icon.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnProductPicture.setIcon(icon)

    def setCursor(self, object, position):
        cursor = object.textCursor()
        cursor.setPosition(0)
        object.setTextCursor(cursor)

    def setProductFields(self, row):
        try:            
            if row == -1:
                index = self.tblProducts.selectionModel().currentIndex()
                row = index.row()
            product = Product()
            product.name = self.tblProducts.model().index(row, 2).data()
            product.description = self.tblProducts.model().index(row, 3).data()
            product.value = float(self.tblProducts.model().index(row, 4).data().replace(",", "."))
            product.picture = self.tblProducts.model().index(row, 5).data()
            category = Category()            
            for c in CategoryData.categories:                                
                if int(c[0]) == int(self.tblProducts.model().index(row, 1).data()):
                    category.id = int(c[0])
                    category.name = c[1]
                    category.description = c[2]
            product.category = category
            if product.isValid():
                self.pteProductName.setPlainText(product.name)
                self.pteProductDescription.setPlainText(product.description)
                self.pteProductValue.setPlainText("R${:.2f}".format(product.value).replace(".", ","))
                icon = QtGui.QIcon()
                try:
                    imagePath = self.appDir + product.picture
                    if not os.path.exists(imagePath):
                        imagePath = ":/defaultimage_icon.png"
                    icon.addPixmap(QtGui.QPixmap(imagePath), QtGui.QIcon.Normal, QtGui.QIcon.Off)
                except:
                    print("Unexpected error: {}".format(sys.exc_info()[0]))
                self.btnProductPicture.setIcon(icon)
                self.setSelectedCategory(product.category)
        except:
            print("Unexpected error: {}".format(sys.exc_info()[0]))

    def setSelectedCategory(self, category):
        for index in range(self.cbxProductCategories.count()):
            if category.id == self.cbxProductCategories.itemData(index).id:
                self.cbxProductCategories.setCurrentIndex(index)

    def setTblProducts(self):
        self.tblProducts.setHorizontalHeaderLabels(["ID Produto", "ID Categoria", "Nome", 'Descrição', 'Valor (R$)', 'Imagem', 'Categoria'])
        self.tblProducts.setSizeAdjustPolicy(QtWidgets.QAbstractScrollArea.AdjustToContents)
        self.tblProducts.setColumnHidden(0, True)
        self.tblProducts.setColumnHidden(1, True)
        self.tblProducts.setColumnHidden(3, True)
        self.tblProducts.setColumnHidden(5, True)

    def fillTblProducts(self):
        products = self.getAllProducts()        
        self.tblProducts.setRowCount(len(products))
        is_empty = len(products) < 1
        if not is_empty:
            self.lblTblProductsEmpty.hide()
            for i, product in enumerate(products):
                fields = list(product.values())
                for j, col in enumerate(fields):
                    item = QTableWidgetItem(str(col))
                    if j == 4:
                        item.setTextAlignment(int(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter))
                    self.tblProducts.setItem(i, j, item)
            self.tblProducts.resizeColumnsToContents()
            self.tblProducts.sortItems(2, QtCore.Qt.AscendingOrder)
        else:
            self.lblTblProductsEmpty.show()
        self.tblProducts.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff if is_empty else QtCore.Qt.ScrollBarAsNeeded)
        self.tblProducts.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff if is_empty else QtCore.Qt.ScrollBarAsNeeded)
        self.tblProducts.setColumnWidth(2, 440)

    def getAllProducts(self):
        tuples = ProductData.loadProducts()
        products = []
        for tuple in tuples:
            products.append({"id": tuple[0], "idCategory": tuple[1], "name": tuple[2], "description": tuple[3], "value": tuple[4], "picture": tuple[5], "nameCategory": tuple[6]})
        return products

    def setCbxProductCategories(self):
        lne = QtWidgets.QLineEdit()
        lne.setReadOnly(True)
        lne.selectionChanged.connect(lambda: lne.setSelection(0, 0))
        lne.setPlaceholderText("Selecione uma categoria");
        self.cbxProductCategories.setLineEdit(lne)

    def fillCbxProductCategories(self):
        self.cbxProductCategories.clear()
        categories = self.getAllCategories()
        if len(categories) > 0:
            self.cbxProductCategories.setEditable(False)
            for categ in categories:
                category = Category()
                category.id = categ["id"]
                category.name = categ["name"]
                category.description = categ["description"]
                if category.isValid():
                    self.cbxProductCategories.addItem(categ["name"], category)
        else:
            self.cbxProductCategories.setEditable(True)
            self.cbxProductCategories.setCurrentText("Nenhuma categoria encontrada")

    def getAllCategories(self):
        tuples = CategoryData.loadCategories()
        categories = []
        for tuple in tuples:
            categories.append({"id": tuple[0], "name": tuple[1], "description": tuple[2]})
        return categories

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    pv = ProductsView()
    sys.exit(app.exec_())
